# Scratch Text-To-Numbers (TTN)

This is how you use Scratch TTN.

##### How To Use Encoding
___
To encode a string, simply use this code: `encode('example')`. Replace `example` with your own text.

**Note:** You can *ONLY* use lowercase letters and numbers.

##### How To Use Decoding
___
To decode a string, use `decode('example')`, and replace `example` with your own text.

**Again, *You can ONLY use lowercase letters and numbers.***

##### Scratchblocks
___

To decode encoded items in Scratch, export  [this project](https://scratch.mit.edu/), load it in Scratch, and backpack the custom block definitions. Then go to the project that you want the blocks to be in, open your backpack, and drag-n-drop the two custom block definitions to your project.

> Report bugs to me! -Joecooldoo on Github!