'''
Have PyPi Open!
To update, go to Shell, run "cd scratch-text-to-nums".
To create a new release, simply change line one of package-name/package-name/__init__.py to the new version, and line three of package-name/pyproject.toml. poetry update, poetry build, and poetry publish!
'''